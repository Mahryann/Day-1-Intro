
# Day 1 – My Web Dev Journey Begins

Today I created my first HTML file using Acode on my phone and opened it in the browser.

## 📌 What I Did
- Installed Acode
- Created a project folder: `day1-intro`
- Wrote basic HTML
- Opened the file in my browser

## 💡 What I Learned
- Structure of an HTML page (`<html>`, `<head>`, `<body>`)
- How to create and preview a webpage using Acode

## 📝 Next Step
Start learning the basics of CSS and how to style an HTML page.